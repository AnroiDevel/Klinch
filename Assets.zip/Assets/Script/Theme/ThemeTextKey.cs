namespace Game.Theme
{
    public enum ThemeTextKey
    {
        None,
        BattlePhase,
        ShufflePhase,
        Attack,
        Heal,
        Ready,
        YouWin,
        YouLose
    }
}
