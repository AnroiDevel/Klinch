namespace Game.Theme
{
    public enum ThemeSpriteKey
    {
        None,
        IconAttack,
        IconHeal,
        IconTimer,
        IconPhaseBattle,
        IconPhaseShuffle,
        CardFrame,
        CardBack
    }
}
